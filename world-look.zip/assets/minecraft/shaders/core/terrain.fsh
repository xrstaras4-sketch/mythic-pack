#version 330
#extension GL_ARB_separate_shader_objects : require

// MythicTerritories "MMO terrain" (26.3 only, from the pack overlay mmo_look): the vanilla terrain shader, but every block is drawn richer -
// more colour, a soft S-curve of contrast, and on solid blocks a painted bevel (a light top-left and a dark bottom-right edge on every
// 16 x 16 tile), so the world reads like hand-painted MMORPG terrain. Same inputs and outputs as the vanilla terrain.fsh.

#include <minecraft:fog.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:texture_sampling.glsl>
#include <minecraft:oit.glsl>
#include <minecraft:terrainglobals.glsl>
#ifndef MULTIDRAW_TERRAIN
    #include <minecraft:chunksection.glsl>
#endif

uniform sampler2D Sampler0;

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) in float chunkVisibility;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

const float SATURATION = 1.25;
const float CONTRAST = 0.35;    // share of the S-curve mixed in
const float BEVEL_LIGHT = 0.06; // top-left edge of a tile
const float BEVEL_DARK = 0.11;  // bottom-right edge of a tile (stronger reads as a grid on big grass fields)

vec3 grade(vec3 c) {
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = max(mix(vec3(l), c, SATURATION), 0.0);
    vec3 s = c * c * (3.0 - 2.0 * c);
    return clamp(mix(c, s, CONTRAST), 0.0, 1.0);
}

float bevel(vec2 uv) {
    vec2 f = mod(uv * TextureSize, 16.0);
    float e = 0.0;
    if (f.x < 1.0 || f.y < 1.0) e += BEVEL_LIGHT;
    if (f.x >= 15.0 || f.y >= 15.0) e -= BEVEL_DARK;
    return 1.0 + e;
}

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif
    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

void main() {
    vec4 tex = UseRgss == 1 ? sampleRGSS(Sampler0, texCoord0, 1.0f / TextureSize) : sampleNearest(Sampler0, texCoord0, 1.0f / TextureSize);
    #if !defined(ALPHA_CUTOUT) && !defined(OIT_ACCUMULATE) && !defined(OIT_ALPHA_ONLY)
    if (tex.a > 0.99) tex.rgb *= bevel(texCoord0); // (solid pixels only: plants, leaves, glass and water keep clean edges)
    #endif
    vec4 color = tex * vertexColor;
    color.rgb = grade(color.rgb);
    #ifndef OIT_ALPHA_ONLY
    color = mix(FogColor * vec4(1, 1, 1, color.a), color, chunkVisibility);
    #endif
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
