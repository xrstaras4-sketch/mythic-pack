#version 330
#extension GL_ARB_separate_shader_objects : require

// MythicTerritories: the vanilla entity shader plus the tier shimmer of the class armor. Texels with alpha 254 / 253 / 252 (only our
// armor layers have them; every other client draws them opaque) get a silver / gold / blue light sweeping over them and a soft pulse.
// Alpha 251 (1.76.0, the Rift sets' seams, emblems, gems and high trims): the texel GLOWS - no darkness from night or shade, a slow pulse.
#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
layout(location = 2) in vec4 vertexPerFaceColorBack;
layout(location = 3) in vec4 vertexPerFaceColorFront;
#else
layout(location = 2) in vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) in vec4 overlayColor;
#endif

layout(location = 6) in vec2 texCoord0;
#ifdef GLINT
layout(location = 7) in vec2 texCoordGlint;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

float mtShimmer = 0.0;
vec3 mtTint = vec3(0.0);
float mtGlow = 0.0;

vec4 calculateFinalColor(vec4 color) {
    #ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    #endif

    #ifndef EMISSIVE
    color *= mix(lightMapColor, vec4(1.0), mtGlow);
    #endif

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color.rgb += mtTint * mtShimmer * 0.45; // (the shimmer also shines a little in the dark)
    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

void main() {
    vec4 color = texture(Sampler0, texCoord0);

    #ifdef ALPHA_CUTOUT
    int mtMark = int(color.a * 255.0 + 0.5);
    if (mtMark == 251) {
        float secs = GameTime * 1200.0;
        mtGlow = 1.0;
        color.rgb *= 1.12 + 0.16 * sin(secs * 2.4 + texCoord0.y * 18.0);
        color.a = 1.0;
    } else if (mtMark >= 252 && mtMark <= 254) {
        mtTint = mtMark == 254 ? vec3(0.90, 0.94, 1.00) : (mtMark == 253 ? vec3(1.00, 0.78, 0.32) : vec3(0.30, 0.66, 1.00));
        float secs = GameTime * 1200.0;
        float ph = fract(texCoord0.x * 1.3 + texCoord0.y * 0.9 - secs * 0.3);
        float band = pow(clamp(1.0 - abs(ph - 0.5) / 0.12, 0.0, 1.0), 1.5);
        float pulse = 0.16 + 0.08 * sin(secs * 3.14159);
        mtShimmer = band * 0.85 + pulse;
        color.rgb = color.rgb * (1.0 - 0.35 * mtShimmer) + mtTint * mtShimmer;
        color.a = 1.0;
    }
    #endif

    #ifdef OIT_ADDITIVE
    color.a = min(0.99, color.a);
    #endif

    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
    #else
    vec4 faceVertexColor = vertexColor;
    #endif

    #ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
        discard;
    }
    // The dissolve effect entirely replaces translucency
    faceVertexColor.a = 1.0;
    #endif

    color *= mix(faceVertexColor, vec4(1.0, 1.0, 1.0, faceVertexColor.a), mtGlow) * ColorModulator; // (a glowing texel ignores the shading too)

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
