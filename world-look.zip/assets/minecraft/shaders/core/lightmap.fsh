#version 330
#extension GL_ARB_separate_shader_objects : require

// MythicTerritories "MMO light" (26.3 only, from the pack overlay mmo_look): the vanilla lightmap with a warm golden sun, warm torches,
// and shadows that fall off into a cool blue instead of grey - the painted look of an MMORPG. Same inputs and outputs as vanilla.

layout(std140) uniform LightmapInfo {
    float SkyFactor;
    float BlockFactor;
    float NightVisionFactor;
    float DarknessScale;
    float BossOverlayWorldDarkeningFactor;
    float BrightnessFactor;
    vec3 BlockLightTint;
    vec3 SkyLightColor;
    vec3 AmbientColor;
    vec3 NightVisionColor;
} lightmapInfo;

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

float get_brightness(float level) {
    return level / (4.0 - 3.0 * level);
}

vec3 notGamma(vec3 color) {
    float maxComponent = max(max(color.x, color.y), color.z);
    float maxInverted = 1.0f - maxComponent;
    float maxScaled = 1.0f - maxInverted * maxInverted * maxInverted * maxInverted;
    return color * (maxScaled / maxComponent);
}

float parabolicMixFactor(float level) {
    return (2.0 * level - 1.0) * (2.0 * level - 1.0);
}

const vec3 SUN_TINT = vec3(1.08, 1.00, 0.86);   // golden daylight
const vec3 TORCH_TINT = vec3(1.06, 0.96, 0.82); // warm fire light
const vec3 SHADOW_TINT = vec3(0.035, 0.05, 0.10); // what the dark parts drift towards (cool blue)

void main() {
    float block_level = floor(texCoord.x * 16) / 15;
    float sky_level = floor(texCoord.y * 16) / 15;

    float block_brightness = get_brightness(block_level) * lightmapInfo.BlockFactor;
    float sky_brightness = get_brightness(sky_level) * lightmapInfo.SkyFactor;

    vec3 nightVisionColor = lightmapInfo.NightVisionColor * lightmapInfo.NightVisionFactor;
    vec3 color = max(lightmapInfo.AmbientColor, nightVisionColor);

    color += lightmapInfo.SkyLightColor * SUN_TINT * sky_brightness;

    vec3 BlockLightColor = mix(lightmapInfo.BlockLightTint, vec3(1.0), 0.9 * parabolicMixFactor(block_level)) * TORCH_TINT;
    color += BlockLightColor * block_brightness;

    // shadows: the less light reaches a spot, the more it takes the cool shadow colour (never pitch grey)
    float lit = clamp(max(sky_brightness, block_brightness), 0.0, 1.0);
    color += SHADOW_TINT * (1.0 - lit) * (1.0 - lightmapInfo.DarknessScale);

    color = mix(color, color * vec3(0.7, 0.6, 0.6), lightmapInfo.BossOverlayWorldDarkeningFactor);
    color = color - vec3(lightmapInfo.DarknessScale);

    color = clamp(color, 0.0, 1.0);
    vec3 notGamma = notGamma(color);
    color = mix(color, notGamma, lightmapInfo.BrightnessFactor);

    fragColor = vec4(color, 1.0);
}
